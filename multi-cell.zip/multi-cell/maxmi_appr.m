capacity_cumu = zeros(K, L);
for tfr = 1 : time_fre_resources
    for l1 = 1 : L
        [~, Csel] = sort(capacity_cumu, 'descend');
        C_len = K - sum(ill_cond_s(:, l1));
        Csel_temp = zeros(C_len, 1);
        k_xx = 0;
        for k_x = 1 : K
            if ill_cond_s(Csel(k_x, 1), l1) > 0
            else
                k_xx = k_xx + 1;
                Csel_temp(k_xx, 1) = Csel(k_x, 1);
            end
        end
        Csel = Csel_temp;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        H1B_brev = H_Bb_t(:, (l1-1)*K+Csel);
        HM_brev = zeros(Mm, P*length(Csel_temp));
        for k_xx = 1 : length(Csel_temp)
            HM_brev(:, (k_xx-1)*P+1:k_xx*P) = H_Mb_t(:, (l1-1)*P*K*L+(l1-1)*P*K+(Csel_temp(k_xx,1)-1)*P+1:(l1-1)*P*K*L+(l1-1)*P*K+Csel_temp(k_xx,1)*P);
        end
        if cond(H1B_brev'*H1B_brev) > 1e3
            for k_xx = 2 : C_len
                H1B_brev_temp = H_Bb_t(:, (l1-1)*K+Csel(k_xx:C_len, 1));
                Csel_temp = Csel(k_xx:C_len, 1);
                if cond(H1B_brev_temp' * H1B_brev_temp) > 1e3
                else
                    break;
                end
            end
            H1B_brev = H1B_brev_temp;
            Csel = Csel_temp;
        else
        end
        gk_matr = inv(H1B_brev' * H1B_brev);
        switch l1
            case 1
                Csel1 = Csel;
                gk_matr1 = gk_matr;
            case 2
                Csel2 = Csel;
                gk_matr2 = gk_matr;
            case 3
                Csel3 = Csel;
                gk_matr3 = gk_matr;
            otherwise
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
    meth_ind = 2;
    capa_cal;
end


