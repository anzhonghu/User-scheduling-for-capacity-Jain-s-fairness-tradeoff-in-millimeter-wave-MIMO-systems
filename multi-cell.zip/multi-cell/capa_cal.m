%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
%%%capacity calculation%%%%%%%%%%%%%%%
for l1 = 1 : L
    switch l1
        case 1
            Csel = Csel1;
            gk_matr = gk_matr1;
        case 2
            Csel = Csel2;
            gk_matr = gk_matr2;
        case 3
            Csel = Csel3;
            gk_matr = gk_matr3;
        otherwise
    end
    HM_brev = zeros(Mm, P*length(Csel));
    for k_xx = 1 : length(Csel)
        HM_brev(:, (k_xx-1)*P+1:k_xx*P) = H_Mb_t(:, (l1-1)*P*K*L+(l1-1)*P*K+(Csel(k_xx,1)-1)*P+1:(l1-1)*P*K*L+(l1-1)*P*K+Csel(k_xx,1)*P);
    end
    sum_nomi = 0;
    for nc = 1 : length(Csel)
        sum_nomi = sum_nomi + gk_matr(nc, nc) * abs(beta_theta_phi_store((l1-1)*K*L+(l1-1)*K+Csel(nc, 1), 1))^(-2);
    end
    for nc = 1 : length(Csel)
        if block_store(Csel(nc, 1), (l1-1)*L+l1) > 0
            rk_matr = inv(HM_brev(:, (nc-1)*P+2:nc*P)' * HM_brev(:, (nc-1)*P+2:nc*P));
            rk = rk_matr(p_store(Csel(nc, 1), l1)-1,p_store(Csel(nc, 1), l1)-1);
        else
            rk_matr = inv(HM_brev(:, (nc-1)*P+1:nc*P)' * HM_brev(:, (nc-1)*P+1:nc*P));
            rk = rk_matr(p_store(Csel(nc, 1), l1),p_store(Csel(nc, 1), l1));
        end
        if block_store(Csel(nc, 1), (l1-1)*L+l1) > 0
            HM_eff = HM_brev(:, (nc-1)*P+2:nc*P);
            tk_matr = zeros(P-1, P-1);
        else
            HM_eff = HM_brev(:, (nc-1)*P+1:nc*P);
            tk_matr = zeros(P, P);
        end
        for l2 = 1 : L
            if l2 == l1
                continue;
            else
            end
            switch l2
                case 1
                    Csel_x = Csel1;
                    gk_matrxx = gk_matr1;
                case 2
                    Csel_x = Csel2;
                    gk_matrxx = gk_matr2;
                case 3
                    Csel_x = Csel3;
                    gk_matrxx = gk_matr3;
                otherwise
            end
            if block_store(Csel(nc, 1), (l2-1)*L+l1) > 0
                HMjl = H_Mb_t(:, (l2-1)*P*K*L+(l1-1)*P*K+(Csel(nc, 1)-1)*P+2:(l2-1)*P*K*L+(l1-1)*P*K+Csel(nc, 1)*P);
                Xjl = zeros(P-1, P-1);
                for p1 = 1 : P-1
                    for p2 = p1 : P-1
                        Hjlp1 = zeros(Mb, length(Csel));
                        Hjlp2 = zeros(Mb, length(Csel));
                        for nc_nc = 1 : length(Csel)
                            Hjlp1(:, nc_nc) = Hjlp_Bb_t(:, (l2-1)*K*L*P+(l1-1)*K*P+(Csel(nc_nc, 1)-1)*P+p1+1);
                            Hjlp2(:, nc_nc) = Hjlp_Bb_t(:, (l2-1)*K*L*P+(l1-1)*K*P+(Csel(nc_nc, 1)-1)*P+p2+1);
                        end
                        Hll1 = H_Bb_t(:, (l2-1)*K+Csel_x);
                        sum_nomixx = 0;
                        for ncxx = 1 : length(Csel_x)
                            sum_nomixx = sum_nomixx + gk_matrxx(ncxx, ncxx) * abs(beta_theta_phi_store((l2-1)*K*L+(l2-1)*K+Csel_x(ncxx, 1), 1))^(-2);
                        end;
                        HH_for_1 = Hjlp1' * Hll1 / (Hll1'*Hll1);
                        HH_for_2 = Hjlp2' * Hll1 / (Hll1'*Hll1);
                        for k = 1 : length(Csel_x)
                            sigma_lclk_2 = PB / sum_nomixx / abs(beta_theta_phi_store((l2-1)*K*L+(l2-1)*K+Csel_x(ncxx, 1), 1))^2;
                            Xjl(p1, p2) = Xjl(p1, p2) + beta_store(Csel(nc, 1), (l2-1)*P*L+(l1-1)*P+p1+1)...
                                * beta_store(Csel(nc, 1), (l2-1)*P*L+(l1-1)*P+p2+1)' * sigma_lclk_2 *...
                                HH_for_1(nc, k) * HH_for_2(nc, k);
                        end
                        Xjl(p2, p1) = Xjl(p1, p2)';
                    end
                end
            else
                HMjl = H_Mb_t(:, (l2-1)*P*K*L+(l1-1)*P*K+(Csel(nc, 1)-1)*P+1:(l2-1)*P*K*L+(l1-1)*P*K+Csel(nc, 1)*P);
                Xjl = zeros(P, P);
                for p1 = 1 : P
                    for p2 = p1 : P
                        Hjlp1 = zeros(Mb, length(Csel));
                        Hjlp2 = zeros(Mb, length(Csel));
                        for nc_nc = 1 : length(Csel)
                            Hjlp1(:, nc_nc) = Hjlp_Bb_t(:, (l2-1)*K*L*P+(l1-1)*K*P+(Csel(nc_nc, 1)-1)*P+p1);
                            Hjlp2(:, nc_nc) = Hjlp_Bb_t(:, (l2-1)*K*L*P+(l1-1)*K*P+(Csel(nc_nc, 1)-1)*P+p2);
                        end
                        Hll1 = H_Bb_t(:, (l2-1)*K+Csel_x);
                        sum_nomixx = 0;
                        for ncxx = 1 : length(Csel_x)
                            sum_nomixx = sum_nomixx + gk_matrxx(ncxx, ncxx) * abs(beta_theta_phi_store((l2-1)*K*L+(l2-1)*K+Csel_x(ncxx, 1), 1))^(-2);
                        end;
                        HH_for_1 = Hjlp1' * Hll1 / (Hll1'*Hll1);
                        HH_for_2 = Hjlp2' * Hll1 / (Hll1'*Hll1);
                        for k = 1 : length(Csel_x)
                            sigma_lclk_2 = PB / sum_nomixx / abs(beta_theta_phi_store((l2-1)*K*L+(l2-1)*K+Csel_x(ncxx, 1), 1))^2;
                            Xjl(p1, p2) = Xjl(p1, p2) + beta_store(Csel(nc, 1), (l2-1)*P*L+(l1-1)*P+p1)...
                                * beta_store(Csel(nc, 1), (l2-1)*P*L+(l1-1)*P+p2)' * sigma_lclk_2 *...
                                HH_for_1(nc, k) * HH_for_2(nc, k);
                        end
                        Xjl(p2, p1) = Xjl(p1, p2)';
                    end
                end
            end
            tk_matr = tk_matr + rk_matr * HM_eff' * HMjl * Xjl * HMjl' * HM_eff * rk_matr';
        end
        if block_store(Csel(nc, 1), (l1-1)*L+l1) > 0
            tk = abs(tk_matr(p_store(Csel(nc, 1), l1)-1,p_store(Csel(nc, 1), l1)-1));
        else
            tk = abs(tk_matr(p_store(Csel(nc, 1), l1),p_store(Csel(nc, 1), l1)));
        end
        rk = rk + tk;
        capacity(variable_n, meth_ind) = capacity(variable_n, meth_ind) + log2(1 + PB/(sum_nomi * rk));
        if 1==ii && length(variable_s)==variable_n
            capacity_cdf((l1-1)*K+Csel(nc, 1), meth_ind) = capacity_cdf((l1-1)*K+Csel(nc, 1), meth_ind) + log2(1 + PB/(sum_nomi * rk));
        else
        end
    end
end