for l1 = 1 : L
    capa_cu_s = zeros(K, L);
    for k = 1 : K
        H1B_brev = H_Bb_t(:, (l1-1)*K+k);
        gk_matr = inv(H1B_brev' * H1B_brev);
        sum_nomi = gk_matr(1, 1) * abs(beta_theta_phi_store((l1-1)*K*L+(l1-1)*K+k, 1))^(-2);
        HM_brev = H_Mb_t(:, (l1-1)*P*K*L+(l1-1)*P*K+(k-1)*P+1:(l1-1)*P*K*L+(l1-1)*P*K+k*P);
        if ill_cond_s(k, l1) < 1
            if block_store(k, (l1-1)*L+l1) > 0
                rk_matr = inv(HM_brev(:, 2:P)' * HM_brev(:, 2:P));
                rk = rk_matr(p_store(k, l1)-1,p_store(k, l1)-1);
            else
                rk_matr = inv(HM_brev(:, 1:P)' * HM_brev(:, 1:P));
                rk = rk_matr(p_store(k, l1),p_store(k, l1));
            end
            capa_cu_s(k, l1) = log2(1 + PB/(sum_nomi * rk));
        else
        end
    end
end
capacity_cumu = zeros(K, L);
for tfr = 1 : time_fre_resources
    for l1 = 1 : L
        pf_ratio_store = zeros(K, 1);
        for k = 1 : K
            if capacity_cumu(k, 1) > 0
                pf_ratio_store(k, 1) = capa_cu_s(k, l1) / capacity_cumu(k, l1);
            else
                pf_ratio_store(k, 1) = capa_cu_s(k, l1) * 1e8;%%%?
            end
        end
        [~, Csel] = sort(pf_ratio_store, 'ascend');
        C_len = K - sum(ill_cond_s(:, l1));
        Csel_temp = zeros(C_len, 1);
        k_xx = 0;
        for k_x = 1 : K
            if ill_cond_s(Csel(k_x, 1), l1) > 0
            else
                k_xx = k_xx + 1;
                Csel_temp(k_xx, 1) = Csel(k_x, 1);
            end
        end
        Csel = Csel_temp;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        H1B_brev = H_Bb_t(:, (l1-1)*K+Csel);
        HM_brev = zeros(Mm, P*length(Csel_temp));
        for k_xx = 1 : length(Csel_temp)
            HM_brev(:, (k_xx-1)*P+1:k_xx*P) = H_Mb_t(:, (l1-1)*P*K*L+(l1-1)*P*K+(Csel_temp(k_xx,1)-1)*P+1:(l1-1)*P*K*L+(l1-1)*P*K+Csel_temp(k_xx,1)*P);
        end
        if cond(H1B_brev'*H1B_brev) > 1e3
            for k_xx = 2 : C_len
                H1B_brev_temp = H_Bb_t(:, (l1-1)*K+Csel(k_xx:C_len, 1));
                Csel_temp = Csel(k_xx:C_len, 1);
                if cond(H1B_brev_temp' * H1B_brev_temp) > 1e3
                else
                    break;
                end
            end
            H1B_brev = H1B_brev_temp;
            Csel = Csel_temp;
        else
        end
        gk_matr = inv(H1B_brev' * H1B_brev);
        switch l1
            case 1
                Csel1 = Csel;
                gk_matr1 = gk_matr;
            case 2
                Csel2 = Csel;
                gk_matr2 = gk_matr;
            case 3
                Csel3 = Csel;
                gk_matr3 = gk_matr;
            otherwise
        end
         sum_nomi = 0;
        for nc = 1 : length(Csel_temp)
            sum_nomi = sum_nomi + gk_matr(nc, nc) * abs(beta_theta_phi_store((l1-1)*K*L+(l1-1)*K+Csel_temp(nc, 1), 1))^(-2);
        end
        for nc = 1 : length(Csel_temp)
            if block_store(Csel_temp(nc, 1), (l1-1)*L+l1) > 0
                rk_matr = inv(HM_brev(:, (nc-1)*P+2:nc*P)' * HM_brev(:, (nc-1)*P+2:nc*P));
                rk = rk_matr(p_store(Csel_temp(nc, 1), l1)-1,p_store(Csel_temp(nc, 1), l1)-1);
            else
                rk_matr = inv(HM_brev(:, (nc-1)*P+1:nc*P)' * HM_brev(:, (nc-1)*P+1:nc*P));
                rk = rk_matr(p_store(Csel_temp(nc, 1), l1),p_store(Csel_temp(nc, 1), l1));
            end
            capacity_cumu(Csel_temp(nc, 1), l1) = capacity_cumu(Csel_temp(nc, 1), l1) + log2(1 + PB/(sum_nomi * rk));
        end
    end
    meth_ind = 3;
    capa_cal;
end


