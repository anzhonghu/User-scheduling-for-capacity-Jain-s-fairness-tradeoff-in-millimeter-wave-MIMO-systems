clear;
close all;
L = 3;
naz = 32;
nel = 151;
n_arr = naz * nel;
maz = 3;
mel = 4;
m_arr = maz * mel;
Rmin = 10;
Rmax = 100;
base = [0, 0; 0,  2 * Rmax; sqrt(3) * Rmax,  Rmax;];
beam_numberforMS = 2;
beam_numberforBS = 8;
P = 4;
PB = 1e11;
variable_s = [10; 20; 30; 40; 50;];
height = 10;
time_fre_resources = 20;
f = 80*10^9;%1G bandwidth
lambda = 3 * 10^8 / f;
miu = 0.5;
beta_m = 10.3 * pi / 180;%-phi_m in the EL paper
Nite = 1e3;
capacity = zeros(length(variable_s),  4);
capacity_cdf = zeros(variable_s(length(variable_s), 1) * L,  4);
angle = zeros(1, 2);
U = zeros(n_arr, n_arr);
for nx = 1 : naz
    for ny = 1 : nel
        angle(1, 2) = (-1+2*ny/nel);%el
        angle(1, 1) = (-1+2*nx/naz);%az
        n = (ny - 1) * naz + nx;
        for mx = 0 : naz-1
            for my = 0 : nel-1
                m = my * naz + 1 + mx;
                U(m, n) = exp(-1i * 2 * pi * miu * ((mx-0.5*(naz-1)) * angle(1, 1) + (my-0.5*(nel-1)) * angle(1, 2))) / sqrt(n_arr);
            end
        end
    end
end
Um = zeros(m_arr, m_arr);
for nx = 1 : maz
    for ny = 1 : mel
        angle(1, 2) = (-1+2*ny/mel);%el
        angle(1, 1) = (-1+2*nx/maz);%az
        n = (ny - 1) * maz + nx;
        for mx = 0 : maz-1
            for my = 0 : mel-1
                m = my * maz + 1 + mx;
                Um(m, n) = exp(-1i * 2 * pi * miu * ((mx-0.5*(maz-1)) * angle(1, 1) + (my-0.5*(mel-1)) * angle(1, 2))) / sqrt(m_arr);
            end
        end
    end
end
for variable_n = 1 : length(variable_s)
    K = variable_s(variable_n, 1);
    HpB = zeros(n_arr, K*L*L*P);%1~L 1st BS to cells, L+1~2L, 2nd BS to cell, ..., (L-1)*L+1~L*L, Lth BS to cells
    H1B = zeros(n_arr, K*L);% channel BS
    HM = zeros(m_arr, P*K*L*L);% channel MS
    Mb = beam_numberforMS * K;
    Mm = beam_numberforBS;
    p_store = zeros(K, L);
    beta_store = zeros(K, P*L*L);
    for ii = 1 : Nite
        pos_store = zeros(K*L, 2);
        for l = 1 : L
            for k = 1 : K
                pos_temp = zeros(1, 2);
                while norm(pos_temp) < Rmin || norm(pos_temp) > Rmax || abs(atan(pos_temp(1, 2) / pos_temp(1, 1))) > pi / 3
                    pos_temp(1, 1) = rand(1, 1) * Rmax;
                    pos_temp(1, 2) = (rand(1, 1) * 2 - 1) * Rmax;
                end
                pos_store((l-1)*K+k, :) = pos_temp;%relative to the serving BS
            end
        end
        pos = zeros(K, 3);
        theta = zeros(K, P);
        phi = zeros(K, P);
        beta = zeros(K, P);
        beta_theta_phi_store = zeros(K*L*L, 3);
        theta_m = zeros(K, P);
        phi_m = zeros(K, P);
        block_store = zeros(K, L*L);
        ill_cond_s = zeros(K, L);
        Beam_indi_l1l2 = zeros(K, K);
        Beam_indi_l2l3 = zeros(K, K);
        Beam_indi_l1l3 = zeros(K, K);
        for l1 = 1  : L
            for l2 = 1 : L
                for k = 1 : K
                    for p = 1 : P
                        if 1==p
                            pos_temp = pos_store((l2-1)*K+k, :) + base(l2, :)-base(l1, :);%%relative position of MS in the l2-th cell to l1-th BS
                            pos(k, 3) = norm(pos_temp);
                            pos(k, 3) = norm([pos(k, 3), height]);%distance
                            if rand(1,1)>0.1
                                phi(k, p) = asin(pos_temp(1, 2) / sqrt(pos_temp(1, 2)^2 + (pos_temp(1, 1) * cos(beta_m) + height * sin(beta_m))^2));%az
                                theta(k, p) = asin((pos_temp(1, 1) * sin(beta_m) - height * cos(beta_m)) / pos(k, 3));%el
                                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                phi_m(k, p) = pi - phi(k, p);
                                theta_m(k, p) = pi - theta(k, p);
                            else
                                block_store(k, (l1-1)*L+l2) = 1;
                                beta(k, p) = 0;
                                continue;
                            end
                        else
                            %take the reflector inside the cell
                            pos_temp = zeros(1, 2);
                            while norm(pos_temp) < Rmin || norm(pos_temp) > Rmax || abs(atan(pos_temp(1, 2) / pos_temp(1, 1))) > pi / 3
                                pos_temp(1, 1) = rand(1, 1) * Rmax;
                                pos_temp(1, 2) = (rand(1, 1) * 2 - 1) * Rmax;
                            end
                            pos_temp = pos_temp  + base(l2, :)-base(l1, :);
                            pos(k, 3) = norm(pos_temp);
                            pos(k, 3) = norm([pos(k, 3), height]);%distance
                            phi(k, p) = asin(pos_temp(1, 2) / sqrt(pos_temp(1, 2)^2 + (pos_temp(1, 1) * cos(beta_m) + height * sin(beta_m))^2));%az
                            theta(k, p) = asin((pos_temp(1, 1) * sin(beta_m) - height * cos(beta_m)) / pos(k, 3));%el
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            phi_m(k, p) = pi - phi(k, p);
                            theta_m(k, p) = pi - theta(k, p);
                        end
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        Aaz = -min(12 * phi(k, p)^2 / (70/180*pi)^2, 25);
                        Ael = -min(12 * theta(k, p)^2 / (7/180*pi)^2, 20);
                        D0 = -min(-Aaz-Ael, 25);
                        D0 = 10^(D0*0.1);
                        if p < 2
                            beta(k, p) = sqrt(D0 * lambda^2 / (16 * pi^2 * pos(k, 3)^2)) * exp(1i * rand(1,1) * 2 * pi);
                        else
                            beta(k, p) = sqrt(D0 * lambda^2 / (16 * pi^2 * pos(k, 3)^2)) * exp(1i * rand(1,1) * 2 * pi) * 10^((-rand(1,1) * 5 - 15)*0.05);%-15~-20dB loss
                        end
                        hb = zeros(n_arr, 1);
                        for nx = 0 : naz-1
                            for ny = 0 : nel-1
                                n = ny * naz+ 1 + nx;
                                hb(n, 1) = exp(-1i * 2 * pi * miu * ((nx-0.5*(naz-1)) * cos(theta(k, p)) * sin(phi(k, p)) + (ny-0.5*(nel-1)) * sin(theta(k, p))));
                            end
                        end
                        hm = zeros(m_arr, 1);
                        for nx = 0 : maz-1
                            for ny = 0 : mel-1
                                n = ny * maz+ 1 + nx;
                                hm(n, 1) = exp(-1i * 2 * pi * miu * ((nx-0.5*(maz-1)) * cos(theta_m(k, p)) * sin(phi_m(k, p)) + (ny-0.5*(mel-1)) * sin(theta_m(k, p))));
                            end
                        end
                        HpB(:, (l1-1)*K*L*P+(l2-1)*K*P+(k-1)*P+p) = hb;
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        HM(:, (l1-1)*P*K*L+(l2-1)*P*K+(k-1)*P+p) = hm;
                        beta_store(k, (l1-1)*P*L+(l2-1)*P+p) = beta(k, p);
                    end
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    [~, p] = max(abs(beta(k, :)));
                    if l1 == l2
                        p_store(k, l1) = p;
                        H1B(:, (l1-1)*K+k) = HpB(:, (l1-1)*K*L*P+(l2-1)*K*P+(k-1)*P+p);
                    else
                    end
                    beta_theta_phi_store((l1-1)*K*L+(l2-1)*K+k, :) = [beta(k, p), theta(k, p), phi(k, p)];
                end
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        H_Bb_t = zeros(Mb, K*L);
        Hjlp_Bb_t = zeros(Mb, K*L*L*P);
        H_Bb =  U' * H1B;
        Hjlp_Bb = U' * HpB;
        for l1 = 1 : L
            Db = zeros(Mb, 1);
            diff = 1e4 * ones(n_arr, 1);
            [~, uhein] = sort(abs(H_Bb(:,(l1-1)*K+1:l1*K)), 'descend');
            for k = 1 : K
                counttemp = 0;
                for n = 1 : n_arr
                    if diff(uhein(n,k), 1) > 0
                        diff(uhein(n,k), 1) = 0;
                        counttemp = counttemp + 1;
                        Db((k-1)*beam_numberforMS+counttemp, 1) = uhein(n,k);
                    else
                    end
                    if counttemp < beam_numberforMS
                    else
                        break;
                    end
                end
            end
            H_Bb_t(:, (l1-1)*K+1:l1*K) = H_Bb(Db, (l1-1)*K+1:l1*K);%%Mb*K*L
            Hjlp_Bb_t(:, (l1-1)*K*L*P+1: l1*K*L*P) = Hjlp_Bb(Db, (l1-1)*K*L*P+1: l1*K*L*P);
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Dm = zeros(Mm, K);
        H_Mb =  Um' * HM;
        H_Mb_t = zeros(beam_numberforBS, K*P*L*L);
        for l2 = 1 : L
            for k = 1 : K
                [~, uhein] = sort(abs(H_Mb(:,(l2-1)*P*K*L+(l2-1)*P*K+(k-1)*P+p_store(k, l2))), 'descend');
                Dm(:, k) = uhein(1:Mm,1);
                for l1 = 1 : L
                    H_Mb_t(:, (l1-1)*P*K*L+(l2-1)*P*K+(k-1)*P+1:(l2-1)*P*K*L+(l2-1)*P*K+k*P) = H_Mb(Dm(:,k), (l1-1)*P*K*L+(l2-1)*P*K+(k-1)*P+1:(l2-1)*P*K*L+(l2-1)*P*K+k*P);
                end
                if block_store(k, (l2-1)*L+l2)  > 0
                    rk_matr_cond = H_Mb_t(:, (l2-1)*P*K*L+(l2-1)*P*K+(k-1)*P+2:(l2-1)*P*K*L+(l2-1)*P*K+k*P)'...
                        * H_Mb_t(:, (l2-1)*P*K*L+(l2-1)*P*K+(k-1)*P+2:(l2-1)*P*K*L+(l2-1)*P*K+k*P);
                else
                    rk_matr_cond = H_Mb_t(:, (l2-1)*P*K*L+(l2-1)*P*K+(k-1)*P+1:(l2-1)*P*K*L+(l2-1)*P*K+k*P)'...
                        * H_Mb_t(:, (l2-1)*P*K*L+(l2-1)*P*K+(k-1)*P+1:(l2-1)*P*K*L+(l2-1)*P*K+k*P);
                end
                if cond(rk_matr_cond) > 1e3
                    ill_cond_s(k, l2) = 1;
                else
                end
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        cac;%4
        oppor_appr;%1
        maxmi_appr;%2
        pf_appr;%3
        disp([variable_n, ii])
    end
end
capacity(:, 2:4) = capacity(:, 2:4) / Nite / time_fre_resources;
capacity(:, 1) = capacity(:, 1) / Nite;
capacity_cdf(:, 2:4) = capacity_cdf(:, 2:4) / time_fre_resources;
capacity_cdf = sort(capacity_cdf, 1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h1 = subplot(1,2,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot(variable_s, capacity(1:length(variable_s), 1), 'k--s','LineWidth',1,'MarkerSize',10)
hold on
plot(variable_s, capacity(1:length(variable_s), 2), 'k--*','LineWidth',1,'MarkerSize',10)
plot(variable_s, capacity(1:length(variable_s), 3), 'k--o','LineWidth',1,'MarkerSize',12)
plot(variable_s, capacity(1:length(variable_s), 4), 'k-^','LineWidth',1,'MarkerSize',10)
xlim([min(variable_s), max(variable_s)])
le = legend('Opportunistic','max-min','PF','Proposed', 'Location', 'northwest');
set(le,'Fontname','Times')
set(gca,'XTick',variable_s)
xlabel('Number of MSs','Fontname','Times')
ylabel('Sum capacity (bps/Hz)','Fontname','Times')
grid on
%%%%%%%%%%%%%%%%%%%%%%%%
h2 = subplot(1,2,2);
capacity_plot = zeros(10,  4);
for plot_nn = 1 : 10
    capacity_plot(plot_nn, :) = capacity_cdf(variable_s(length(variable_s), 1)  * L * plot_nn*0.1, :);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F1 = cdfplot(capacity_cdf(:, 1));
% set(F1,'LineWidth',2,'Color','k','LineStyle', '--')
% hold on
% plot(capacity_plot(:,1),(1:10)*0.1, 'ks','MarkerSize',10)
% F2 = cdfplot(capacity_cdf(:, 2));
% set(F2,'LineWidth',2,'Color','k','LineStyle', '--')
% plot(capacity_plot(:,2),(1:10)*0.1, 'k*','MarkerSize',10)
% F3 = cdfplot(capacity_cdf(:, 3));
% set(F3,'LineWidth',2,'Color','k','LineStyle', '--')
% plot(capacity_plot(:,3),(1:10)*0.1, 'ko','MarkerSize',10)
% F4 = cdfplot(capacity_cdf(:, 4));
% set(F4,'LineWidth',2,'Color','k','LineStyle', '-')
% plot(capacity_plot(:,4),(1:10)*0.1, 'k^','MarkerSize',10)
% xlabel('Capacity (bps/Hz)','Fontname','Times')
% ylabel('CDF','Fontname','Times')
% grid on
% title('')
plot(capacity_plot(:,1),(1:10)*0.1, 'k-s','MarkerSize',10)
hold on
plot(capacity_plot(:,2),(1:10)*0.1, 'k-*','MarkerSize',10)
plot(capacity_plot(:,3),(1:10)*0.1, 'k-o','MarkerSize',12)
plot(capacity_plot(:,4),(1:10)*0.1, 'k-^','MarkerSize',10)
xlabel('Capacity (bps/Hz)','Fontname','Times')
ylabel('CDF','Fontname','Times')
grid on
title('')
