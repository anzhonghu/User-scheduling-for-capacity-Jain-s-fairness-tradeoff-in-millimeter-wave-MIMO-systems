clear;
close all;
naz = 4;
nel = 8;
nb = naz * nel;
nn = 10;
cor = zeros(nn*naz+1, nn*nel+1);
X = zeros(nn*naz+1, nn*nel+1);
Y = zeros(nn*naz+1, nn*nel+1);
for nx = 0 : nn*naz
    for ny = 0 : nn*nel
        if abs(nn*naz/2-nx)<1e-1
            c1 = naz;
        else
            angle1 = (-1+2*nx/naz/nn);%az
            q1 = exp(1i*pi*angle1);
            c1 = (1-q1^naz)/(1-q1);
        end
        if abs(nn*nel/2-ny)<1e-1
            c2 = nel;
        else
            angle2 = (-1+2*ny/nel/nn);%el
            q2 = exp(1i*pi*angle2);
            c2 = (1-q2^nel)/(1-q2);
        end
        cor(nx+1,ny+1) = abs(c1*c2)/nb;
        X(nx+1,ny+1) = -1+2*nx/naz/nn;
        Y(nx+1,ny+1) = -1+2*ny/nel/nn;
    end
end

h = figure;
set(h,'PaperType','A4');
axes('FontSize',16);
contourf(X,Y,cor);
xlabel('cos\phi_{1k}^Bsin\theta_{1k}^B','Fontsize',20,'Fontname','Times')
ylabel('sin\phi_{1k}^B','Fontsize',20,'Fontname','Times')
grid on
colormap autumn
colorbar
print(h,'-dpdf','fig_cor')
